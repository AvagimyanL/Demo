﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TemplateApp;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Test_Microsoft
{
    public partial class MainMenu : Form
    {
        private readonly DbContext dbContext;
        private readonly Form parent;
        private string tableName;
        private int indexRow = -1;
        public MainMenu()
        {
            InitializeComponent();

            NpgsqlConnectionStringBuilder builder = new NpgsqlConnectionStringBuilder();
            builder.Host = "localhost";
            builder.Port = 5432;
            builder.Database = "Test_demo";
            builder.Username = "postgres";
            builder.Password = "0000";

            dbContext = new DbContext(builder);
        }

        public MainMenu(DbContext dbContext, Form parent)
        {
            InitializeComponent();
            this.dbContext = dbContext;
            this.parent = parent;


        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tableName = "users";    //Название таблицы базы данных
            DataTable table = dbContext.GetTable(tableName);

            dataGridView1.Rows.Clear();

            dataGridView1.RowCount = table.Rows.Count;
            dataGridView1.ColumnCount = table.Columns.Count;

            for (int i = 0; i < dataGridView1.ColumnCount; i++)
                dataGridView1.Columns[i].HeaderText = table.Columns[i].ColumnName;

            for (int row = 0; row < table.Rows.Count; row++)
            {
                for (int column = 0; column < table.Columns.Count; column++)
                {
                    dataGridView1[column, row].Value = table.Rows[row][column].ToString();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tableName == null)
            {
                MessageBox.Show("Сначала нужно вывести записи", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            AddPage addPage = new AddPage(dbContext, tableName);
            addPage.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (indexRow == -1)
            {
                MessageBox.Show("Выберите строку", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DataTable table = dbContext.GetTable(tableName);
            DataRow row = table.NewRow();
            for (int column = 0; column < dataGridView1.ColumnCount; column++)
            {
                row[column] = dataGridView1[column, indexRow].Value;
            }

            dbContext.DeleteRow(row, tableName);
            indexRow = -1;
            button1_Click(null, null);
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            DataTable table = dbContext.GetTable(tableName);
            DataRow row = table.NewRow();
            for (int column = 0; column < dataGridView1.ColumnCount; column++)
            {
                row[column] = dataGridView1[column, e.RowIndex].Value;
            }

            AddPage addPage = new AddPage(dbContext, tableName, row);
            addPage.ShowDialog();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            indexRow = e.RowIndex;
        }

        private void MainMenu_FormClosing(object sender, FormClosingEventArgs e)
        {
          Application.Exit();
        }
    }
}
