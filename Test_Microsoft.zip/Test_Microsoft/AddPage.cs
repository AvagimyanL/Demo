﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TemplateApp;

namespace Test_Microsoft
{
    public partial class AddPage : Form
    {
        private readonly DbContext dbContext;
        private readonly string tableName;
        private readonly DataRow row;
        public AddPage()
        {
            InitializeComponent();
            panel2.Controls.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        public AddPage(DbContext dbContext, string tableName) //Режим добавления записи
        {
            InitializeComponent();
            this.dbContext = dbContext;
            this.tableName = tableName;
            panel2.Controls.Clear();

            DataTable table = dbContext.GetTable(tableName);

            foreach (DataColumn column in table.Columns)
            {
                panel2.Controls.Add(
                    renderBox(column.ColumnName)
                    );
            }
        }

        public AddPage(DbContext dbContext, string tableName, DataRow row) //Режим редактировния записи
        {
            InitializeComponent();
            this.dbContext = dbContext;
            this.tableName = tableName;
            this.row = row;
            panel2.Controls.Clear();

            DataTable table = dbContext.GetTable(tableName);
            int index = 0;
            foreach (DataColumn column in table.Columns)
            {
                GroupBox box = renderBox(column.ColumnName);
                TextBox text = box.Controls[0] as TextBox;

                if (text == null) continue;

                text.Text = row[index].ToString();
                panel2.Controls.Add(box);
                index++;
            }
        }

        private GroupBox renderBox(string param) //Шаблонизатор полей
        {
            GroupBox box = new GroupBox()
            {
                Text = param,
                Top = groupBox1.Top,
                Left = groupBox1.Left,
                Dock = groupBox1.Dock,
                Width = groupBox1.Width,
                Height = groupBox1.Height
            };

            TextBox textBox = new TextBox()
            {
                Top = groupBox1.Top,
                Left = groupBox1.Left,
                Dock = groupBox1.Dock,
                Width = groupBox1.Width,
                Height = groupBox1.Height
            };

            box.Controls.Add(textBox);
            return box;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DataTable table = dbContext.GetTable(tableName);
            DataRow rowAfter = null;
            rowAfter = table.NewRow();

            int index = 0;

            foreach (Control control in panel2.Controls)
            {
                GroupBox box = control as GroupBox;

                if (box.Controls[0] is TextBox text)
                {
                    rowAfter[index] = text.Text;
                    index++;
                }
            }

            if (row == null)
            {
                if (dbContext.GetByKey(rowAfter[0], tableName) != null)
                {
                    MessageBox.Show("Пользователь с таким идентификатором уже существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                dbContext.AddRow(rowAfter, tableName);
            }
            else
            {
                dbContext.Update(row, rowAfter, tableName);
            }

            this.DialogResult = DialogResult.OK;
        }
    }
}
